﻿using UnityEngine;
using System.Collections;

public class Element : PT_MonoBehaviour {
	public ElementType type;
}
